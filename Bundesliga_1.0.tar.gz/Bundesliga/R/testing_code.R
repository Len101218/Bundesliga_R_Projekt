#Check ob alle benötigten Packages bereits installiert wurden, falls nicht werden diese installiert.
if(!"tidyverse" %in% rownames(installed.packages())){
  install.packages("tidyverse")
}
if(!"devtools" %in% rownames(installed.packages())){
  install.packages("devtools")
}
if(!"here" %in% rownames(installed.packages())){
  install.packages("here")
}


library(here)
library(tidyverse)
library(usethis)
library(devtools)


library(here)

if(!exists("filter_data", mode="function")) source(here("R/filter.R"))

bigFive<-read_data_from_csv(here("Csv/BigFive.csv")) 

filter_data(data=bigFive,saison_von=2016,saison_bis=2018,ligen="Premier-league")
